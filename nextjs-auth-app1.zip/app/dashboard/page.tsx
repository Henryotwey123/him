'use client';

import { useEffect, useState } from 'react';

export default function DashboardPage() {
  const [message, setMessage] = useState('Loading...');

  useEffect(() => {
    const token = localStorage.getItem('token');
    fetch('/api/auth/protected', {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
      .then(res => res.json())
      .then(data => {
        if (data.message) setMessage(data.message);
        else setMessage(data.error || 'Unauthorized');
      });
  }, []);

  return <div className="p-4">{message}</div>;
}