import { NextResponse } from 'next/server';
import { verify } from 'jsonwebtoken';

export async function GET(req: Request) {
  const authHeader = req.headers.get('authorization');
  if (!authHeader) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const token = authHeader.replace('Bearer ', '');

  try {
    const decoded = verify(token, process.env.SECRET_KEY as string) as { userId: number };
    return NextResponse.json({ message: `Welcome, user ${decoded.userId}!` });
  } catch {
    return NextResponse.json({ error: 'Invalid token' }, { status: 401 });
  }
}